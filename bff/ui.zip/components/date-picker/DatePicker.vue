<script setup lang="ts">
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-vue-next';
import { fromDate, parseDate, CalendarDate } from '@internationalized/date';
import {
  DatePickerArrow,
  DatePickerCalendar,
  DatePickerCell,
  DatePickerCellTrigger,
  DatePickerContent,
  DatePickerField,
  DatePickerGrid,
  DatePickerGridBody,
  DatePickerGridHead,
  DatePickerGridRow,
  DatePickerHeadCell,
  DatePickerHeader,
  DatePickerHeading,
  DatePickerInput,
  DatePickerNext,
  DatePickerPrev,
  DatePickerRoot,
  DatePickerTrigger,
} from 'reka-ui/DatePicker'
import { useVModel } from '@vueuse/core'
import { type FormControlVariants, formControlVariants } from '../form/theme'
import { buttonVariants } from '../button'
import type { HTMLAttributes } from 'vue'

const props = defineProps<{
  defaultValue?: string
  modelValue?: string
  class?: HTMLAttributes['class']
  size?: FormControlVariants['size']
}>()
const emits = defineEmits<{
  (e: 'update:modelValue', payload: string): void
}>()

const modelValue = useVModel(props, 'modelValue', emits, {
  passive: true,
  defaultValue: props.defaultValue,
})
const handlePlaceholder = (date) => {
  emits('update:modelValue', date?.toString());
}
const handleUpdateValue = (date) => {
  open.value = false
  emits('update:modelValue', date.toString());
}
const open = ref(false)
const d = new Date(props.modelValue || Date.now())
const value = (props.modelValue ? new CalendarDate(d.getFullYear(), d.getMonth() + 1, d.getDate()): undefined)
</script>

<template>
  <DatePickerRoot :default-value="value" v-model:open="open" @update:modelValue="handleUpdateValue">
    <DatePickerField
      v-slot="{ segments }"
      class="border rounded py-1 ps-2 px-1.5 flex items-center"
      @update:modelValue="handlePlaceholder"
    >
      <div class="flex items-center flex-1">
        <template
          v-for="item in segments"
          :key="item.part"
        >
          <DatePickerInput
            v-if="item.part === 'literal'"
            :part="item.part"
          >
            {{ item.value }}
          </DatePickerInput>
          <DatePickerInput
            v-else
            :part="item.part"
            :class="[formControlVariants({variant: 'ghost', size: 'none'}), 'data-placeholder:text-muted-foreground']"
          >
            {{ item.value }}
          </DatePickerInput>
        </template>
      </div>

      <DatePickerTrigger as-child>
        <Button :icon="true" size="xs" variant="ghost" class="outline-none">
          <Calendar class="size-4"/>
        </Button>
      </DatePickerTrigger>
    </DatePickerField>

    <DatePickerContent
      :side-offset="8"
      class="border bg-popover text-popover-foreground shadow outline-hidden rounded z-50"
    >
      <DatePickerCalendar
        v-slot="{ weekDays, grid }"
        class="p-4"
      >
        <DatePickerHeader class="flex items-center justify-between">
          <DatePickerPrev
            :class="cn(
              buttonVariants({ variant: 'ghost', size: 'sm', icon: true }),
            )"
          >
            <ChevronLeft
              class="w-4 h-4"
            />
          </DatePickerPrev>

          <DatePickerHeading class="" />
          <DatePickerNext
            :class="cn(
              buttonVariants({ variant: 'ghost', size: 'sm', icon: true }),
            )"
          >
            <ChevronRight
              class="w-4 h-4"
            />
          </DatePickerNext>
        </DatePickerHeader>
        <div
          class="flex flex-col space-y-4 pt-4 sm:flex-row sm:space-x-4 sm:space-y-0"
        >
          <DatePickerGrid
            v-for="month in grid"
            :key="month.value.toString()"
            class="w-full border-collapse select-none space-y-1"
          >
            <DatePickerGridHead>
              <DatePickerGridRow class="mb-1 flex w-full justify-between">
                <DatePickerHeadCell
                  v-for="day in weekDays"
                  :key="day"
                  class="w-8 rounded-md text-xs text-foreground/50"
                >
                  {{ day }}
                </DatePickerHeadCell>
              </DatePickerGridRow>
            </DatePickerGridHead>
            <DatePickerGridBody>
              <DatePickerGridRow
                v-for="(weekDates, index) in month.rows"
                :key="`weekDate-${index}`"
                class="flex w-full"
              >
                <DatePickerCell
                  v-for="weekDate in weekDates"
                  :key="weekDate.toString()"
                  :date="weekDate"
                >
                  <DatePickerCellTrigger
                    :day="weekDate"
                    :month="month.value"
                    class="relative flex items-center justify-center whitespace-nowrap rounded border border-transparent bg-transparent text-sm w-8 h-8 outline-none focus:shadow-[0_0_0_2px] focus:shadow-primary/40 hover:bg-accent data-[selected]:bg-accent data-[selected]:font-medium data-[disabled]:text-muted data-[selected]:text-primary data-[unavailable]:pointer-events-none data-[unavailable]:text-black/30 data-[unavailable]:line-through before:absolute before:top-[5px] before:hidden before:rounded-full before:w-1 before:h-1 before:bg-foreground data-[today]:before:block data-[today]:before:bg-primary data-[selected]:before:bg-foreground"
                  />
                </DatePickerCell>
              </DatePickerGridRow>
            </DatePickerGridBody>
          </DatePickerGrid>
        </div>
      </DatePickerCalendar>
    </DatePickerContent>
  </DatePickerRoot>
</template>