<script setup lang="ts">
// import { cn } from '@/lib/utils'
import { TagsInputInput, type TagsInputInputProps } from 'reka-ui/TagsInput'
import { useForwardProps } from 'reka-ui/utilities'
import { computed, type HTMLAttributes } from 'vue'

const props = defineProps<TagsInputInputProps & { class?: HTMLAttributes['class'] }>()

const delegatedProps = computed(() => {
  const { class: _, ...delegated } = props

  return delegated
})

const forwardedProps = useForwardProps(delegatedProps)
</script>

<template>
  <TagsInputInput v-bind="forwardedProps" :class="cn('text-sm min-h-6 focus:outline-hidden flex-1 bg-transparent px-1', props.class)" />
</template>
