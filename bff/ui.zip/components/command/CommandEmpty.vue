<script setup lang="ts">
import type { ComboboxEmptyProps } from 'reka-ui/Combobox'
import { ComboboxEmpty } from 'reka-ui/Combobox'
import { computed, type HTMLAttributes } from 'vue'

const props = defineProps<ComboboxEmptyProps & { class?: HTMLAttributes['class'] }>()

const delegatedProps = computed(() => {
  const { class: _, ...delegated } = props

  return delegated
})
</script>

<template>
  <ComboboxEmpty v-bind="delegatedProps" :class="cn('min-h-10 text-center text-sm flex items-center justify-center text-muted-foreground', props.class)">
    <slot />
  </ComboboxEmpty>
</template>
