<script setup lang="ts" generic="T extends ZodRawShape">
import type { ZodAny, ZodObject, ZodRawShape } from 'zod'
import type { Config, ConfigItem, Shape } from './interface'
import { FieldContextKey, useField } from 'vee-validate'
import { computed, provide } from 'vue'
import { getBaseSchema, getBaseType, getDefaultValueInZodStack } from './utils'
import { FoldVertical, UnfoldVertical } from 'lucide-vue-next'

const props = defineProps<{
  fieldName: string
  required?: boolean
  config?: Config<T>
  schema?: ZodObject<T>
  disabled?: boolean
}>()

const shapes = computed(() => {
  // @ts-expect-error ignore {} not assignable to object
  const val: { [key in keyof T]: Shape } = {}

  if (!props.schema)
    return
  const shape = getBaseSchema(props.schema)?.shape
  if (!shape)
    return
  Object.keys(shape).forEach((name) => {
    const item = shape[name] as ZodAny
    const baseItem = getBaseSchema(item) as ZodAny
    let options = (baseItem && 'values' in baseItem._def) ? baseItem._def.values as string[] : undefined
    if (!Array.isArray(options) && typeof options === 'object')
      options = Object.values(options)

    val[name as keyof T] = {
      type: getBaseType(item),
      default: getDefaultValueInZodStack(item),
      options,
      required: !['ZodOptional', 'ZodNullable'].includes(item._def.typeName),
      schema: item,
    }
  })
  return val
})

const fieldContext = useField(props.fieldName)
// @ts-expect-error ignore missing `id`
provide(FieldContextKey, fieldContext)
const { layout } = inject('AutoForm')

</script>

<template>
  <section>
    <slot v-bind="props">
      <Collapsible v-slot="{open}" type="single" class="w-full bg-muted/50 rounded p-1 ps-3" collapsible :disabled="disabled" :unmountOnHide="false" :defaultOpen="true">
        <div class="flex items-center justify-between">
          <AutoFormLabel class="text-base" :required="required">
            {{ schema?.description || camelCase(fieldName) }}
          </AutoFormLabel>
          <CollapsibleTrigger as-child>
            <Button :icon="true" variant="ghost" size="sm">
              <FoldVertical class="size-4" v-if="open"/>
              <UnfoldVertical class="size-4" v-else="open"/>
            </Button>
          </CollapsibleTrigger>
        </div>
        <CollapsibleContent class="space-y-3" as-child>
          <FormItem v-bind="$attrs" :layout="layout">
            <template v-for="(shape, key) in shapes" :key="key">
              <AutoFormField
                :config="{
                  ...config?.[key as keyof typeof config],
                  component: config?.field?.fieldTypes ? config?.field?.fieldTypes[key] : 'Textbox'
                } as ConfigItem"
                :field-name="`${fieldName}.${key.toString()}`"
                :label="key.toString()"
                :shape="shape"
              />
            </template>
          </FormItem>
        </CollapsibleContent>
      </Collapsible>
    </slot>
  </section>
</template>
