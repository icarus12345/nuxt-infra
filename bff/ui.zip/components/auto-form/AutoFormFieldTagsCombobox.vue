<script setup lang="ts">
import { Check, ChevronDown } from 'lucide-vue-next';
import { ComboboxAnchor, ComboboxContent, ComboboxInput, ComboboxPortal, ComboboxRoot, ComboboxTrigger, ComboboxItem, ComboboxItemIndicator, ComboboxViewport } from 'reka-ui/Combobox'
import { menuItemVariants } from '#ui/components/theme/menu'

const options = [
  { value: 'next.js', label: 'Next.js' },
  { value: 'sveltekit', label: 'SvelteKit' },
  { value: 'nuxt', label: 'Nuxt' },
  { value: 'remix', label: 'Remix' },
  { value: 'astro', label: 'Astro' },
]
const modelValue = ref<string[]>([])
const open = ref(false)
const query = ref('')
watch(modelValue, () => {
  query.value = ''
}, { deep: true })
// const filteredFrameworks = computed(() => options.filter(i => !modelValue.value.includes(i.label)))
const filteredOptions = computed(() => options.filter(option => option.label.includes(query.value)))

</script>

<template>
  <ComboboxRoot v-model="modelValue" v-model:open="open" multiple as-child>
    <ComboboxAnchor>
      <TagsInput :model-value="modelValue" class="p-1 w-full pr-6 relative">
        <TagsInputItem v-for="item in modelValue" :key="item" :value="item">
          <TagsInputItemText />
          <TagsInputItemDelete />
        </TagsInputItem>
        <ComboboxInput placeholder="Framework..." as-child v-model="query">
          <TagsInputInput class="px-2" @keydown.enter.prevent />
        </ComboboxInput>
        <ComboboxTrigger class="absolute right-2 top-1/2 -mt-2 data-[state=open]:rotate-180">
          <ChevronDown class="size-4"/>
        </ComboboxTrigger>
      </TagsInput>
    </ComboboxAnchor>

    <ComboboxPortal>
      <ComboboxContent position="popper" class="z-50 overflow-hidden rounded shadow will-change-[opacity,transform]">
        <CommandList
          class="w-[var(--reka-combobox-trigger-width)] rounded mt-1 border bg-popover text-popover-foreground shadow"
        >
          <CommandEmpty />
          <CommandGroup>
            <CommandItem
              v-for="option in options" :key="option.value" :value="option.label"
              class="ps-6"
            >
            <ComboboxItemIndicator as-child
              class="absolute left-1 top-1/2 -mt-2"
            >
              <Check class="size-4"/>
            </ComboboxItemIndicator>
              {{ option.label }}
            </CommandItem>
          </CommandGroup>
        </CommandList>
      </ComboboxContent>
    </ComboboxPortal>
  </ComboboxRoot>
</template>