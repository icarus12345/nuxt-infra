<script setup lang="ts">
// import { cn } from '@/lib/utils'
import { ToastViewport, type ToastViewportProps } from 'reka-ui'
import { computed, type HTMLAttributes } from 'vue'

const props = defineProps<ToastViewportProps & { class?: HTMLAttributes['class'] }>()

const delegatedProps = computed(() => {
  const { class: _, ...delegated } = props

  return delegated
})
</script>

<template>
  <ToastViewport v-bind="delegatedProps" :class="cn('fixed top-4 z-100 flex max-h-screen w-full gap-2  right-4 flex-col md:max-w-[320px]', props.class)" />
</template>
