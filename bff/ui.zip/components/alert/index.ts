import { tv, type VariantProps } from 'tailwind-variants';

export { default as Alert } from './Alert.vue'
export { default as AlertDescription } from './AlertDescription.vue'
export { default as AlertTitle } from './AlertTitle.vue'

export const alertVariants = tv(
  {
    base: 'relative w-full rounded-lg border p-4 [&>svg]:text-foreground [&>svg]:float-left [&>svg]:mr-2',
    variants: {
      variant: {
        default: 'bg-background text-foreground',
        destructive:
          'border-destructive/50 dark:border-destructive [&>svg]:text-destructive bg-destructive/10',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
)

export type AlertVariants = VariantProps<typeof alertVariants>
