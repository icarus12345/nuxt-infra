import { tv, type VariantProps } from 'tailwind-variants';

export const formControlVariants = tv(
  {
    base: 'ring-offset-background placeholder:text-muted-foreground aria-valuetext:empty:text-muted-foreground focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring  disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:bg-destructive/10 aria-invalid:border-destructive autofill:bg-background',
    variants: {
      variant: {
        default: 'flex h-8 w-full border border-input bg-background focus-visible:ring-offset-2',
        ghost: 'focus-visible:ring-offset-0',
      },
      size: {
        xs: 'h-6 rounded-xs px-2 text-xs',
        sm: 'h-7 rounded-sm px-2.5 text-sm',
        default: 'h-8 px-4 rounded py-2 px-3 text-sm',
        none: 'rounded-xs',
      },
    },
    defaultVariants: {
      size: 'default',
      variant: 'default',
    },
  },
)

export type FormControlVariants = VariantProps<typeof formControlVariants>

export const formItemVariants = tv(
  {
    base: '',
    variants: {
      layout: {
        float: 'grid grid-cols-[12rem_1fr] gap-2',
        default: 'flex flex-col gap-1',
      },
    },
    defaultVariants: {
      layout: 'default',
    },
  },
)

export type FormItemVariants = VariantProps<typeof formItemVariants>