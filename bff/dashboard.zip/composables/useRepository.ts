import { $ApiClient } from '@gateways';
import { IAttribute, IEntity } from '@entities';
import { IConditions, IResource, IResourceList, IRepository } from '@interfaces';
import { EntityMapper } from '@mappers';

export const useRepository = (resource: string): IRepository => {
  async function get(id: string, params?: IConditions): Promise<IResource<IEntity>> {
    try {
      const result: IResource<IEntity> = await $ApiClient.get(`/api/v1/${resource}/${id}`, params);
      return EntityMapper.toEntity<IEntity>(result)
    } catch (error) {
      throw error;
    }
  }
  async function fetch(params: IConditions): Promise<IResource<IEntity[]>> {
    try {
      const result: IResourceList<IEntity[]> = await $ApiClient.get(`/api/v1/${resource}`, params);
      return EntityMapper.toEntities<IEntity>(result)
    } catch (error) {
      throw error;
    }
  }
  async function post(attributes: Partial<IAttribute>): Promise<IEntity> {
    try {
      const result: IResource<IEntity> = await $ApiClient.post(`/api/v1/${resource}`, {
        data: {
          type: resource,
          ...attributes
        },
        include: attributes.relationships ? Object.keys(attributes.relationships) : undefined
      });
      return result.data;
    } catch (error) {
      throw error;
    }
  }

  async function patch(entity: IEntity): Promise<IEntity> {
    try {
      const result: IResource<IEntity> = await $ApiClient.patch(`/api/v1/${resource}/${entity.id}`, {
        data: {
          type: resource,
          ...entity
        },
        include: entity.relationships ? Object.keys(entity.relationships) : undefined
      });
      return result.data;
    } catch (error) {
      throw error;
    }
  }
  return {
    resource,
    get,
    fetch,
    post,
    patch,
    async save(entity: IEntity): Promise<IEntity> {
      if(entity.id) {
        return patch(entity)
      }
      return post(entity)
    },

    async delete(id: number): Promise<boolean> {
      try {
        return await $ApiClient.delete(`/api/v1/${resource}/${id}`);
      } catch (error) {
        throw error;
      }
    },
  }
}