<script lang="ts" setup>
import { type DialogContentProps } from 'reka-ui'
import { IEntity } from '@entities'
import { h, onMounted } from 'vue'
import { FieldSchema, IDataSource, IResource } from '@interfaces'
type DetailDialogProps = DialogContentProps & {
  entity?: IEntity
  schema: FieldSchema
  source: IDataSource
}
const formRef = ref(null);
const props = defineProps<DetailDialogProps>()
const loading = ref(true);
const handleInteractOutside = (event) => {
  // Ngăn đóng khi click outside
  event.preventDefault();
};
const handleKeydown = (event) => {
  if (event.key === 'Escape') {
    // Ngăn đóng khi nhấn phím ESC
    event.preventDefault();
  }
};

const editingEntity = ref(props.entity)

onMounted(async () => {
  if (props.entity?.id && props.source.get) {
    const resource: IResource = await props.source.get(props.entity.id);
    editingEntity.value = resource.data
  }

  loading.value = false
})
</script>
<template>
  <DialogContent
    :size="schema.size ?? 'xs'"
    class="grid-rows-[auto_minmax(0,1fr)_auto]"
    @keydown="handleKeydown"
    @interact-outside="handleInteractOutside">
    <DialogHeader>
      <DialogTitle>{{ entity?.id ? 'Edit ' : 'Create new a' }} {{ schema.name }}</DialogTitle>
      <DialogDescription>{{ schema.description }}</DialogDescription>
    </DialogHeader>
    <DetailAutoForm ref="formRef" :entity="editingEntity" :schema="schema" :source="source" v-if="!loading"/>
    <div v-else class="py-12 text-center">Loading...</div>
    <DialogFooter v-if="formRef">
      <DialogClose as-child class="ms-auto">
        <Button variant="ghost">Close</Button>
      </DialogClose>
      <Button variant="soft" @click="formRef.doSubmit" :loading="formRef.loading">{{ entity ? 'Save' : 'Create' }}</Button>
    </DialogFooter>
  </DialogContent>
</template>