<script lang="ts" setup>
import { IEntity } from '@entities'
import * as z from 'zod'
import { FieldSchema, IDataSource } from '@interfaces'
import { toTypedSchema } from '@vee-validate/zod'
import { useForm } from 'vee-validate'
import DetailDIalogToolbar from './DetailDIalogToolbar.vue'
const $Toast = useToast()
const dialog = inject('Dialog')
type DetailDialogProps = {
  entity?: IEntity
  schema: FieldSchema
  source: IDataSource
}
const props = defineProps<DetailDialogProps>()
const obj = {}
const fieldConfig = {}
// const tabs = 
let fields = props.schema.fields
const schemas = fields.filter(field => field.schema).map(field => field.schema)
fields.forEach(field => {
  const dataField = field.dataField
  obj[dataField] = field.shape
  let value = getValueByPath(props.entity, field.displayField || dataField)
  if (!value) {
    if (field.shape instanceof z.ZodArray) {
      value = []
    }
  }
  if (value) {
    obj[dataField] = field.shape.default(value)
  }
  fieldConfig[dataField] = {
    component: field.component || field.fieldType,
    field: field,
    description: field.hint
  }
})
const loading = ref(false);
const formSchema = z.object(obj)
function onSubmit(values: Record<string, any>) {
  const entity = objectToEntity(values, fields)
  loading.value = true;
  props.source
  .save({
    id: props.entity?.id,
    ...entity
  })
  .then(() => {
    $Toast.alert({
      variant: 'success',
      description: `${props.entity?.id ? 'Update' : 'Create a'} Entity Success!`,
    })
    if (dialog) {
      dialog.open = false
      dialog.callback()
    }
  })
  .finally(() => (loading.value = false))
  
}
const form = useForm({
  // initialValues: EntityToObject({}, fields),
  validationSchema: toTypedSchema(formSchema),
})
const doSubmit = async ($event) => {
  const isValid = await form.validate(); // Kiểm tra xem form hợp lệ
  if (isValid) {
    form.handleSubmit(onSubmit)(); // Gọi hàm submit
  } else {
    $Toast.alert({
      variant: 'warning',
      description: `Please check your form!`,
    })
  }
}
defineExpose({
  doSubmit,
  loading,
});
</script>
<template>
  <div class="overflow-y-auto -mx-4">
    <AutoForm
      class="grid grid-cols-12 gap-3 px-4 py-1"
      :form="form"
      :schema="formSchema"
      :tabs="schema.tabs"
      :field-config="fieldConfig"
      @submit="onSubmit"
    >
    </AutoForm>
  </div>
</template>