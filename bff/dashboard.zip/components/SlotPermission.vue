<script lang="ts" setup>

import { AlertCircle } from 'lucide-vue-next';

defineProps<{
  permission: string
}>()
</script>
<template>
  <slot v-if="hasPermission(permission)" />
  <div v-else>
    <Alert variant="destructive">
      <AlertCircle class="size-8" />
      <AlertTitle>403 Forbidden</AlertTitle>
      <AlertDescription>
        You don't have permission to access this resource
      </AlertDescription>
    </Alert>
  </div>
</template>